var searchData=
[
  ['ep_5fclausura_5',['Ep_clausura',['../class_n_f_a.html#a4853492370d8b81c67956efe99c66933',1,'NFA::Ep_clausura(std::vector&lt; std::string &gt;)'],['../class_n_f_a.html#affac7e39aed9ef70a0d6cafdb89edf26',1,'NFA::Ep_clausura(std::string, std::vector&lt; std::string &gt; &amp;)']]],
  ['estado_6',['Estado',['../class_estado.html',1,'Estado'],['../class_estado.html#aa956f333e0d0b9c54bc8c94055966ea2',1,'Estado::Estado()'],['../class_estado.html#ac7efa8c467f8e030c6dbc4471fab79dc',1,'Estado::Estado(std::string, bool=0, bool=0)']]]
];
