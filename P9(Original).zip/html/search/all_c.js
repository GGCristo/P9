var searchData=
[
  ['set_5faceptacion_24',['set_Aceptacion',['../class_estado.html#a93223845b225b5cdc65281fa914d7609',1,'Estado']]],
  ['set_5farranque_25',['set_Arranque',['../class_estado.html#a3ab6d65656c056c9c86abf212845bb83',1,'Estado']]],
  ['stream_26',['stream',['../class_fichero.html#a85ad1950380a2544b909ae0d1f5fa9a6',1,'Fichero']]]
];
