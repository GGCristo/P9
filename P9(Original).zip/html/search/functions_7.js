var searchData=
[
  ['insert_5falfabeto_52',['insert_Alfabeto',['../class_n_f_a.html#a64e54b52e26c4809f67ef6bdcbd69ba5',1,'NFA']]],
  ['insert_5festados_53',['insert_Estados',['../class_n_f_a.html#a12ca317c0c67711ae2373905fbf4f2ed',1,'NFA::insert_Estados(std::string)'],['../class_n_f_a.html#aa01f2747782f19e6a245bc792155e020',1,'NFA::insert_Estados(std::string, bool, bool)'],['../class_n_f_a.html#adf66a374660645f337748787390d247c',1,'NFA::insert_Estados(Estado)']]]
];
