var searchData=
[
  ['fichero_43',['Fichero',['../class_fichero.html#a66162fe0fdea8af3c4aee45e34612fed',1,'Fichero']]]
];
