var searchData=
[
  ['get_5faceptacion_8',['get_Aceptacion',['../class_estado.html#a54d26637388cc9e2dabe3035fbbf8074',1,'Estado']]],
  ['get_5farranque_9',['get_Arranque',['../class_estado.html#a353fce3732926df19839bba062d7a1b0',1,'Estado']]],
  ['get_5fe_5farranque_10',['get_E_Arranque',['../class_n_f_a.html#a40e99162f1c97fc660050e4de8b111e6',1,'NFA']]],
  ['get_5fes_5factual_11',['get_Es_Actual',['../class_n_f_a.html#aca0e3a729580b1d51ca88235da1826bf',1,'NFA']]],
  ['get_5fetiqueta_12',['get_Etiqueta',['../class_estado.html#a4fe8a971503e190223201719c6564074',1,'Estado']]],
  ['get_5ffile_5fin_13',['get_File_in',['../class_fichero.html#a055ce086502cc6461bf9cf7a4fdff50d',1,'Fichero']]],
  ['get_5ffile_5fout_14',['get_File_out',['../class_fichero.html#aea61e84ff286a6f3b3d89eaca03d17c3',1,'Fichero']]],
  ['get_5fmapa_15',['get_Mapa',['../class_n_f_a.html#a5aa719c15b112e69b461c3184d5dceb1',1,'NFA::get_Mapa()'],['../class_n_f_a.html#aecad8f41b01fb44f190ec49ee6a0aa83',1,'NFA::get_Mapa() const']]]
];
